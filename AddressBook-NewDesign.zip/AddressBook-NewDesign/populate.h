/*Name   :Shaik Abzal
 batch No: 24021G
 description:AdressBook project work same as like phone contact */
void populateAddressBook(AddressBook* addressBook);
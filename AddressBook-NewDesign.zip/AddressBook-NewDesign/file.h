/*Name   :Shaik Abzal
 batch No: 24021G
 description:AdressBook project work same as like phone contact */
#ifndef FILE_H
#define FILE_H

#include "contact.h"

void saveContactsToFile(AddressBook *addressBook);
void loadContactsFromFile(AddressBook *addressBook);

#endif

/*Name   :Shaik Abzal
 batch No: 24021G
 description:AdressBook project work same as like phone contact */
#include <stdio.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook) {
  
}

void loadContactsFromFile(AddressBook *addressBook) {
    
}
